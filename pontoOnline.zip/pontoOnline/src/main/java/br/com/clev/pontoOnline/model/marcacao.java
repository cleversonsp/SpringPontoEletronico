package br.com.clev.pontoOnline.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity(name="TBSSAR_CADASTRO_BANCO")
public class marcacao {
	
	@Id
	@GeneratedValue
	private String CD_BANCO;
	private String NM_Banco;

	
	public String getCD_BANCO() {
		return CD_BANCO;
	}
	public void setCD_BANCO(String cD_BANCO) {
		CD_BANCO = cD_BANCO;
	}
	public String getNM_Banco() {
		return NM_Banco;
	}
	public void setNM_Banco(String nM_Banco) {
		NM_Banco = nM_Banco;
	}
	
	
	

}
