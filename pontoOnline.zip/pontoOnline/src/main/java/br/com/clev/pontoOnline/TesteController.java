package br.com.clev.pontoOnline;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import br.com.clev.pontoOnline.model.marcacao;
import br.com.clev.pontoOnline.repository.pontoOnlineRepository;

@RestController
public class TesteController {
	
    @Autowired
	private pontoOnlineRepository repository;
	

	@GetMapping(value="/bancos")
	public List<marcacao> listaLancamentos() {
		
		
	Iterable<br.com.clev.pontoOnline.model.marcacao> lista = repository.findAll();

		return (List<marcacao>) lista;
	}
	
	@GetMapping(value ="/soma")
	public int calculo (@RequestParam ("a") int vA, @RequestParam ("b") int vB){
		return vA+vB;
	}
	
	

}
