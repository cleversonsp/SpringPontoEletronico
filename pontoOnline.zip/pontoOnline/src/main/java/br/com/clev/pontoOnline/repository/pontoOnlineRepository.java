package br.com.clev.pontoOnline.repository;

import org.springframework.data.repository.CrudRepository;
import br.com.clev.pontoOnline.model.marcacao;

public interface pontoOnlineRepository extends CrudRepository<marcacao, String> {

}
