package br.com.clev.pontoOnline;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.clev.pontoOnline.repository.pontoOnlineRepository;


@Controller
public class pontoController {
	
	
	@Autowired
	private pontoOnlineRepository repository;
	
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
	@RequestMapping("listaLancamentos")
	public <marcacao> String listaLancamentos(Model model) {
		
		Iterable<br.com.clev.pontoOnline.model.marcacao> lista = repository.findAll();
		model.addAttribute("marcacao", lista);
			
		return "listaLancamentos";
	}

	
	@RequestMapping("marcacao")
	public String marcacao() {
		return "marcacao";
	}
}
